package com.example.myapplication;


public class Country {
    private String name;
    private String region;
    private String code;
    private String capital;
    public Country() {

    }

    public Country(String n, String r, String co, String ca) {
        this.name = n;
        this.region = r;
        this.code = co;
        this.capital = ca;
    }

    public String getName() {
        return name+", "+region;
    }

    public void setName(String n) {
        this.name = n;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setCode(String code) {
        this.code = code;
    }
    public String getCode() {
        return code+"  |";
    }

    public String getCapital() {

        return  "| "+capital;
    }
    public void setCapital(String capital) {
        this.capital = capital;
    }

}